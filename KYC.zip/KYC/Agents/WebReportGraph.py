from langchain.schema import Document
from langgraph.graph import END, StateGraph
from typing_extensions import TypedDict
from typing import List
import functools, operator, requests, os, json
from bs4 import BeautifulSoup
from duckduckgo_search import DDGS
from langchain.agents import AgentExecutor, create_openai_tools_agent
from langchain_core.messages import BaseMessage, HumanMessage
from langchain.output_parsers.openai_functions import JsonOutputFunctionsParser
from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
from langgraph.graph import StateGraph, END
from langchain.tools import tool
from langchain_openai import ChatOpenAI
from typing import Annotated, Any, Dict, List, Optional, Sequence, TypedDict
from duckduckgo_search import AsyncDDGS
import asyncio
import boto3
from langchain_community.document_loaders import WebBaseLoader
from langchain.chains.llm import LLMChain
from langchain_core.prompts import PromptTemplate
from langchain_core.prompts import ChatPromptTemplate
from langchain.prompts import PromptTemplate
from anthropic import AsyncAnthropicBedrock
from langchain_community.llms.bedrock import Bedrock
from langchain_core.output_parsers import StrOutputParser
from langchain_core.output_parsers import JsonOutputParser
from langchain_community.utilities import GoogleSearchAPIWrapper
from langchain.agents import AgentExecutor, create_tool_calling_agent
from langchain_community.tools.tavily_search import TavilySearchResults
from langchain_core.prompts import ChatPromptTemplate
from langchain_community.chat_models import BedrockChat
from langchain import hub
from langchain.agents import AgentExecutor, create_xml_agent
import nest_asyncio
import dotenv
nest_asyncio.apply()
dotenv.load_dotenv()
import os
import time
from concurrent.futures import ThreadPoolExecutor
from Agents import WebSearcher, DocsLoader, SummarizerAgent, WriterAgent, CritiqueAgent
from designer import DesignerAgent
from editor import EditorAgent
from publisher import PublisherAgent

GOOGLE_CSE_ID=os.getenv('google_cse_id')
GOOGLE_API_KEY=os.getenv('google_api_key')
aws_access_key_id = os.getenv('aws_access_key_id')
aws_secret_access_key = os.getenv('aws_secret_access_key')
aws_session_token = os.getenv('aws_session_token')

bedrock = boto3.client(service_name='bedrock-runtime',
region_name='eu-central-1',
aws_access_key_id=aws_access_key_id,
aws_secret_access_key=aws_secret_access_key,
aws_session_token=aws_session_token)

client = AsyncAnthropicBedrock(
    aws_access_key=aws_access_key_id,
    aws_secret_key=aws_secret_access_key,
    aws_session_token=aws_session_token,
    aws_region="us-east-1"
)

llm_claude1 = Bedrock(client=bedrock, model_id="anthropic.claude-instant-v1")
os.environ["GOOGLE_CSE_ID"] = "300550c14bfcf4e4e"
os.environ["GOOGLE_API_KEY"] = "AIzaSyCt5DzUYBOw2YZkwCKVjd8SPsrmkKF4tLI"

class GraphState(TypedDict):
    query: Optional[str] = None
    urls: Optional[str] = None
    docs: Optional[str] = None
    summaries: Optional[str] = None
    report: Optional[str] = None
    grade: Optional[str] = None
    loop: Optional[int] = None


class WebReportGraph:
    def __init__(self):
        self.output_dir = f"outputs/run_{int(time.time())}"
        os.makedirs(self.output_dir, exist_ok=True)

    async def run(self, queries, layout: str):
        # Initialize agents
        search_agent = WebSearcher()
        loader_agent = DocsLoader()
        summarizer_agent = SummarizerAgent(client)
        writer_agent = WriterAgent(client)
        critique_agent = CritiqueAgent(client)
        designer_agent = DesignerAgent(self.output_dir)
        editor_agent = EditorAgent(layout)
        publisher_agent = PublisherAgent(self.output_dir)

        # Define a Langchain graph
        workflow = StateGraph(GraphState)

        # Add nodes for each agent
        workflow.add_node("Web_Searcher", search_agent.run)
        workflow.add_node("DocsLoader", loader_agent.run)
        workflow.add_node("Summarizer", summarizer_agent.run)
        workflow.add_node("ReportGenerator", writer_agent.run)
        workflow.add_node("Corrector", critique_agent.run)

        # Set up edges
        workflow.add_edge("Web_Searcher", "DocsLoader")
        workflow.add_edge("DocsLoader", 'Summarizer')
        workflow.add_edge('Summarizer', "ReportGenerator")
        workflow.add_edge('Corrector', "ReportGenerator")

        def should_continue(state):
            if state['loop']==1:
                return END
            return "Corrector"

        workflow.add_conditional_edges("ReportGenerator", should_continue)

        # set up start and end nodes  # compile the graph
        workflow.set_entry_point("Web_Searcher")

        graph = workflow.compile()
        #with ThreadPoolExecutor() as executor:
        #    parallel_results = list(executor.map(lambda q: graph.ainvoke({"query": q}), queries))

        tasks = [graph.ainvoke({"query": q, 'loop': 0}) for q in queries]
        parallel_results = await asyncio.gather(*tasks)

        # Execute the graph for each query in parallel
        #with ThreadPoolExecutor() as executor:
        #    parallel_results = list(executor.map(lambda q: chain.invoke({"query": q}), queries))

        # Compile the final newspaper
        #newspaper_html = editor_agent.run(parallel_results)
        #newspaper_path = publisher_agent.run(newspaper_html)

        #return newspaper_path
        newspaper_html = editor_agent.run(parallel_results)
        newspaper_path = publisher_agent.run(newspaper_html)

        return newspaper_path
        return parallel_results
    
queries=['Petrobras', 'Vitol', 'Alison Madueke']
webreport=WebReportGraph()

async def main(queries):
    webreport=WebReportGraph()
    await webreport.run(queries)

if __name__ == "__main__":
    asyncio.run(main(queries))
