from flask import Flask, jsonify, request
from WebReportGraph import WebReportGraph
import uvicorn
from fastapi import FastAPI, HTTPException

#backend_app = Flask(__name__)
backend_app = FastAPI()

@backend_app.route('/', methods=['GET'])
def index():
    return jsonify({"status": "Running"}), 200

@backend_app.route('/generate_newspaper', methods=['POST'])
def generate_newspaper():
    data = request.json
    master_agent = WebReportGraph()
    newspaper = master_agent.run(data["topics"], data["layout"])
    return jsonify({"path": newspaper}), 200

if __name__ == "__main__":
    uvicorn.run(backend_app, host="127.0.0.1", port=8000)
    #backend_app.run(port=5000)